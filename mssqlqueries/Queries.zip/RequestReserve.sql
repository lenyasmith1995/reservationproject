USE reservationproject
GO
CREATE TABLE RequestReserve (
	SessionID bigint 
		NOT NULL,
    RequestID bigint 
		NOT NULL,
	ReservationID bigint 
			NULL,
	Solution bit
		NOT NULL,
	TableID int
			NULL,
	PRIMARY KEY (RequestID, ReservationID)
	)