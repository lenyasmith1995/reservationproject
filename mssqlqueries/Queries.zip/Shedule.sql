USE reservationproject
GO
CREATE SEQUENCE NEWSHEDULE AS bigint
 START WITH 1
 INCREMENT BY 1
 MINVALUE -9223372036854775808
 MAXVALUE 9223372036854775807
 CACHE  7
 GO
CREATE TABLE Shedule (
    SheduleID int 
		NOT NULL
		DEFAULT(NEXT VALUE FOR NEWSHEDULE),
	TimeLag time
		NOT NULL,
	MondayStart time
		NOT	NULL,
	MondayEnd time
		NOT	NULL,
	TuesdayStart time
		NOT	NULL,
	TuesdayEnd time
		NOT	NULL,
	WednesdayStart time
		NOT	NULL,
	WednesdayEnd time
		NOT	NULL,
	ThursdayStart time
		NOT	NULL,
	ThursdayEnd time
		NOT	NULL,
	FridayStart time
		NOT	NULL,
	FridayEnd time
		NOT	NULL,
	SaturdayStart time
		NOT	NULL,
	SaturdayEnd time
		NOT	NULL,
	SundayStart time
		NOT	NULL,
	SundayEnd time
		NOT	NULL,
	PRIMARY KEY (SheduleID)
	)