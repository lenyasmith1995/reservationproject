USE reservationproject
GO
CREATE SEQUENCE NEWRESERVATION AS bigint
 START WITH 1
 INCREMENT BY 1
 MINVALUE -9223372036854775808
 MAXVALUE 9223372036854775807
 CACHE  50
 GO
CREATE TABLE Reservation (
    ReservationID bigint 
		NOT NULL
		DEFAULT(NEXT VALUE FOR NEWRESERVATION),
    SessionID nvarchar(200) 
		NOT NULL,
    PlaceID int 
		NOT NULL,
	ContactName nvarchar(50)
		NOT NULL,
	ReservationTimeRequest datetime2
		NOT NULL,
	CommucationID int
		NOT	NULL
		DEFAULT 1,
	ContactString nvarchar(50)
		NOT NULL,
	ContactComment nvarchar(200)
			NULL,
	TableID bigint
		NOT	NULL,
	ClientID bigint
			NULL,
	reservationdate date
		NOT NULL,
	reservationtime time
		NOT NULL,
	reservationcounter tinyint
		NOT NULL,
	AdminAccept bit
		NOT NULL
		DEFAULT 0,
	Cancel bit
		NOT NULL
		DEFAULT 0,
	PRIMARY KEY (ReservationID),
	FOREIGN KEY (PlaceID) REFERENCES Place (PlaceID) ON DELETE NO ACTION,
	FOREIGN KEY (TableID) REFERENCES TableObj (TableID) ON DELETE NO ACTION
	)