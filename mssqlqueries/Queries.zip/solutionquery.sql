IF OBJECT_ID('tempdb..#TempTbl') IS NOT NULL DROP TABLE #TempTbl
DECLARE @StartTime time
DECLARE @EndTime time
DECLARE @ReservationTime time
DECLARE @TimeLag time
DECLARE @RightSide time

SET @StartTime = (SELECT MondayStart
					FROM Shedule
						WHERE SheduleId = 1)
SET @EndTime = (SELECT MondayEnd
					FROM Shedule
						WHERE SheduleId = 1)
SET @TimeLag = (SELECT TimeLag
					FROM Shedule
						WHERE SheduleId = 1)
SET @ReservationTime = '17:30:00'

IF DATEDIFF(HOUR, (SELECT DATEDIFF(HOUR, cast('00:00:00' as time), @ReservationTime)), @EndTime )   < (SELECT DATEDIFF(HOUR, cast('00:00:00' as time),@TimeLag))
       SET @RightSide =  @EndTime
ELSE 
       SET @RightSide = (SELECT DATEADD( HOUR , (SELECT DATEDIFF(HOUR, cast('00:00:00' as time), @TimeLag)) , @ReservationTime))

SELECT @StartTime AS StartTime,  
			@EndTime AS EndTime, 
				@ReservationTime AS ReservationTime, 
					@TimeLag AS TimeLag,
						@RightSide AS RightSide
							INTO #TempTbl

GO

with timetablenew as(
SELECT * 
FROM [dbo].[TIMETABLE]('2020-10-05','2020-11-05')
)

SELECT TB.InsideID, RESERVE  
FROM (
		SELECT TB.InsideID, COUNT(reservationtime) AS RESERVE
		FROM  (timetablenew tt FULL OUTER JOIN TableObj TB
				ON TB.MaxSeats >= 8
				AND TB.MinSeats <= 8
				AND TB.PlaceID = 3
				AND timeOfDay BETWEEN (SELECT StartTime
										FROM #TempTbl
										) AND (SELECT EndTime
												FROM #TempTbl
												)
				AND timeOfDay BETWEEN (SELECT DATEADD(HOUR, DATEDIFF(MINUTE, TimeLag, ReservationTime) / 60,
										DATEADD(MINUTE, DATEDIFF(MINUTE, TimeLag, ReservationTime) / 3600, CAST('00:00:00' AS TIME)))
										FROM #TempTbl
									) AND (SELECT RightSide
										FROM #TempTbl)
				)
									LEFT JOIN Reservation re
			ON tt.timeofday = re.reservationtime
			AND TB.InsideID = re.TableID
			AND reservationdate = '2023-10-23'
		WHERE InsideID IS NOT NULL AND timeOfDay IS NOT NULL
		GROUP BY InsideID
		--ORDER BY MaxSeats ASC, Score DESC, TB.InsideID, timeOfDay ASC

	) AS MYTABLE RIGHT JOIN TableObj TB
		ON TB.InsideID = MYTABLE.InsideID
	WHERE RESERVE IS NOT NULL AND RESERVE < 1
	ORDER BY RESERVE DESC, MaxSeats ASC, Score DESC

OPTION (MAXRECURSION 0)
