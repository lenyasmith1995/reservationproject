USE reservationproject
GO
CREATE FUNCTION TIMETABLE (@StartDate datetime, @EndDate datetime)
RETURNS TABLE
	AS
	RETURN
	(
		WITH theDates AS
			 (
			 SELECT @StartDate as theDate
			  UNION ALL
			  SELECT DATEADD(minute, 1, theDate)
				FROM theDates
			   WHERE DATEADD(minute, 1, theDate) <= @EndDate
			 )
		SELECT CONVERT(TIME,theDate) as timeofday
			FROM theDates
		--OPTION (MAXRECURSION 0)
	);
GO

SELECT * FROM TIMETABLE('2017-03-05','2017-04-05') OPTION (MAXRECURSION 0)