USE reservationproject
GO
INSERT INTO Shedule (TimeLag, 
							MondayStart, MondayEnd, TuesdayStart, TuesdayEnd,
								WednesdayStart, WednesdayEnd, ThursdayStart, ThursdayEnd, FridayStart, FridayEnd,
								   SaturdayStart, SaturdayEnd, SundayStart, SundayEnd )
VALUES ('06:00:00',
			'12:00:00','23:00:00', '12:00:00','23:00:00', 
				'12:00:00','23:00:00', '12:00:00','23:00:00', '12:00:00','23:00:00',
					'12:00:00','23:00:00', '12:00:00','23:00:00')