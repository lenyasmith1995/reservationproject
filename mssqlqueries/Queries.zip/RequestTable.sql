USE reservationproject
GO
CREATE SEQUENCE NEWREQUEST AS bigint
 START WITH 1
 INCREMENT BY 1
 MINVALUE -9223372036854775808
 MAXVALUE 9223372036854775807
 CACHE  100
 GO
CREATE TABLE Request (
    RequestID bigint 
		NOT NULL
		DEFAULT(NEXT VALUE FOR NEWREQUEST),
    SessionID nvarchar(200) 
		NOT NULL,
	PlaceID int 
		NOT NULL,
	requesttime datetime2
		NOT	NULL,
	reservationdate date
		NOT NULL,
	reservationtime time
		NOT NULL,
	reservationcounter tinyint
		NOT NULL,
	ClientID bigint
			NULL,
	Solution bit
		NOT NULL,
	TableID int
			NULL,
	PRIMARY KEY (RequestID),
	)